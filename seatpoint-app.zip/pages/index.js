export default function Home() {
  return (
    <div>
      <h1>SeatPoint - Event Ticketing System / نظام تذاكر الفعاليات</h1>
      <p>Welcome to SeatPoint! Ready for GitHub & Vercel deployment.</p>
      <p>مرحباً بك في سيت بوينت! جاهز للرفع على GitHub والنشر على Vercel.</p>
    </div>
  )
}
